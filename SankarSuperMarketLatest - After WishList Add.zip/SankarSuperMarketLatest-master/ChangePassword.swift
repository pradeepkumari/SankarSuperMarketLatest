
//
//  ChangePassword.swift
//  SankarSuperMarket
//
//  Created by Admin on 6/24/16.
//  Copyright © 2016 vertaceapp. All rights reserved.
//


import Foundation

class ChangePassword
{
       var ID: String
       var Password : String
    
    init?(ID : String, Password : String)
    {
              self.ID = ID
        self.Password = Password
    }
    
    
}
