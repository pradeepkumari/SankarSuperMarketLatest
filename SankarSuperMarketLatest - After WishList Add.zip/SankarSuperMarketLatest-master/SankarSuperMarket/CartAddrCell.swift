//
//  CartAddrCell.swift
//  SankarSuperMarket
//
//  Created by Admin on 6/17/16.
//  Copyright © 2016 vertaceapp. All rights reserved.
//

import UIKit

class CartAddrCell: UITableViewCell {

}
