//
//  WishlistCell.swift
//  SankarSuperMarket
//
//  Created by Admin on 7/14/16.
//  Copyright © 2016 vertaceapp. All rights reserved.
//

import UIKit

class WishlistCell: UITableViewCell {

}
